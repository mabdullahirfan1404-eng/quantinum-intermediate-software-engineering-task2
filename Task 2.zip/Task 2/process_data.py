import pandas as pd
from pathlib import Path

# 1. Define paths assuming process_data.py and data.xlsx are in the SAME directory
BASE_DIR = Path(__file__).parent if "__file__" in locals() else Path(".")
INPUT_FILE = BASE_DIR / "data.xlsx"
OUTPUT_FILE = BASE_DIR / "formatted_pink_morsels.csv"

def process_morsel_excel():
    if not INPUT_FILE.exists():
        print(f"Error: Could not find '{INPUT_FILE.name}' in {BASE_DIR.resolve()}")
        return

    # 2. Read the Excel file
    df = pd.read_excel(INPUT_FILE)

    # Standardize column names to lowercase to prevent matching errors
    df.columns = [str(col).strip().lower() for col in df.columns]

    # 3. Filter strictly for "pink morsel"
    filtered_df = df[df["product"].astype(str).str.strip().str.lower() == "pink morsel"].copy()

    if filtered_df.empty:
        print("Warning: No records found for product 'pink morsel'.")
        return

    # 4. Clean Price column (remove '$' if present and convert to float)
    filtered_df["price"] = (
        filtered_df["price"]
        .astype(str)
        .str.replace("$", "", regex=False)
        .str.strip()
        .astype(float)
    )

    filtered_df["quantity"] = filtered_df["quantity"].astype(float)

    # 5. Compute sales = price * quantity
    filtered_df["sales"] = (filtered_df["price"] * filtered_df["quantity"]).round(2)

    # Clean Region and Date
    filtered_df["region"] = filtered_df["region"].astype(str).str.strip().str.lower()
    filtered_df["date"] = filtered_df["date"].astype(str).str.strip()

    # 6. Select and order only required output fields: sales, date, region
    output_df = filtered_df[["sales", "date", "region"]]

    # 7. Save to CSV in the same folder
    output_df.to_csv(OUTPUT_FILE, index=False)
    print(f"Successfully created '{OUTPUT_FILE.name}' in {BASE_DIR.resolve()} with {len(output_df)} rows!")

if __name__ == "__main__":
    process_morsel_excel()